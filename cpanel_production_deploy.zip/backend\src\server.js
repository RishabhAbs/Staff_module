require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });
const express = require('express');
const cors = require('cors');
const migrate = require('./migrate');

const app = express();

app.use(cors({ origin: '*', credentials: false }));
app.use(express.json());

// Routes
app.use('/api/auth',       require('./routes/auth'));
app.use('/api/staff',      require('./routes/staff'));
app.use('/api/attendance', require('./routes/attendance'));
app.use('/api/leave',      require('./routes/leave'));
app.use('/api/location',   require('./routes/location'));
app.use('/api/shifts',     require('./routes/shifts'));

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

// Serve frontend static files safely (bypasses Apache 403 rules)
const path = require('path');
const frontendPath = path.join(__dirname, '../../');
const fs = require('fs');

// Automatically fix permissions of frontend files recursively
function fixPermissions(dirPath) {
  try {
    if (!fs.existsSync(dirPath)) return;
    const stats = fs.statSync(dirPath);
    if (stats.isDirectory()) {
      fs.chmodSync(dirPath, 0o755);
      const files = fs.readdirSync(dirPath);
      for (const file of files) {
        fixPermissions(path.join(dirPath, file));
      }
    } else {
      fs.chmodSync(dirPath, 0o644);
    }
  } catch (err) {
    console.error(`Failed to fix permissions for ${dirPath}:`, err.message);
  }
}

const expoPath = path.join(frontendPath, '_expo');
const assetsPath = path.join(frontendPath, 'assets');
fixPermissions(expoPath);
fixPermissions(assetsPath);

console.log('--- CPANEL DIAGNOSTICS START ---');
if (fs.existsSync(expoPath)) {
  console.log('[_expo] directory exists. Scanning recursively:');
  const scan = (dir, prefix = '') => {
    try {
      const files = fs.readdirSync(dir);
      files.forEach(f => {
        const full = path.join(dir, f);
        const isDir = fs.statSync(full).isDirectory();
        console.log(`${prefix}├── ${f} [${isDir ? 'DIR' : 'FILE'}]`);
        if (isDir) scan(full, prefix + '│   ');
      });
    } catch (err) {
      console.log('Error scanning:', err.message);
    }
  };
  scan(expoPath);
} else {
  console.log('[_expo] directory does not exist at:', expoPath);
}
console.log('--- CPANEL DIAGNOSTICS END ---');


// Explicitly serve only public directories to prevent exposing /backend
app.use('/_expo', express.static(path.join(frontendPath, '_expo')));
app.use('/expo', express.static(path.join(frontendPath, 'expo')));
app.use('/assets', express.static(path.join(frontendPath, 'assets')));
app.get('/favicon.ico', (req, res) => res.sendFile(path.join(frontendPath, 'favicon.ico')));
app.get('/metadata.json', (req, res) => res.sendFile(path.join(frontendPath, 'metadata.json')));

// Fallback for SPA
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/backend/')) return next();
  res.sendFile(path.join(frontendPath, 'index.html'));
});

const PORT = process.env.PORT || 3001;

// Run migrations then start server
migrate()
  .then(() => {
    app.listen(PORT, '0.0.0.0', () => console.log(`ABS Staff backend running on port ${PORT}`));
  })
  .catch((err) => {
    console.error('Failed to start server due to migration error:', err.message);
    process.exit(1);
  });
