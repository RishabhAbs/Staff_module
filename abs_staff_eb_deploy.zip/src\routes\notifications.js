const router = require('express').Router();
const db     = require('../db');
const auth   = require('../middleware/auth');

// GET all notifications for admin (unread first)
router.get('/', auth, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admins only.' });
  try {
    const [rows] = await db.query(`
      SELECT n.*, s.name as staff_name
      FROM notifications n
      LEFT JOIN staff s ON s.id = n.staff_id
      ORDER BY n.is_read ASC, n.created_at DESC
      LIMIT 50
    `);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET unread count
router.get('/count', auth, async (req, res) => {
  if (req.user.role !== 'admin') return res.json({ count: 0 });
  try {
    const [[{ count }]] = await db.query('SELECT COUNT(*) as count FROM notifications WHERE is_read = 0');
    res.json({ count });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Mark all as read
router.put('/read-all', auth, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admins only.' });
  try {
    await db.query('UPDATE notifications SET is_read = 1');
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Mark single as read
router.put('/:id/read', auth, async (req, res) => {
  try {
    await db.query('UPDATE notifications SET is_read = 1 WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
